# Ecrivez vos fonctions ici

# Ne touchez pas le code ci-dessous
if __name__ == "__main__":
    main()