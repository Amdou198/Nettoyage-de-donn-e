# Instructions  

1. **Créez** une liste nommée `fruits` contenant les éléments `"pomme"`, `"banane"` et `"orange"`.
2. **Ajoutez** `"kiwi"` à la liste `fruits`.
3. **Supprimez** `"orange"` de la liste `fruits`.
4. **Modifiez** le **deuxième** élément de la liste `fruits` en `"ananas"`.
5. **Affichez** la **longueur** de la liste `fruits`.
6. **Triez** la liste `fruits` par ordre alphabétique
7. **Affichez** la liste. *(N'oubliez pas d'afficher la liste pour que les tests passent)*