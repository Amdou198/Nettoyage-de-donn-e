# Écrire le message à l'aide de la fonction print()
print("J'apprends Python !")

#Afficher le résulat d'un calcul
print(17 + 35 * 2)