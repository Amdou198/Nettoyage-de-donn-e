# Création des variables nom et age
nom = "Jean"
age = 25

# Affichage de la phrase avec les variables
print(f"Je m'appelle {nom} et j'ai {age} ans.")

# Modification de la variable age
age = age + 10  #ou "age += 10"

# Affichage de la phrase mise à jour avec les variables
print(f"Je m'appelle {nom} et j'ai {age} ans maintenant.")