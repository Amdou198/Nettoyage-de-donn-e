# Instructions  

#### 1. Dans le module nommé `operations.py`, ajoutez les fonctions suivantes :
* `addition(a, b)`: qui *retourne* la **somme** de deux nombres `a` et `b` ;
* `multiplication(a, b)`: qui *retourne* le **produit** de deux nombres `a` et `b`.

#### 2. Appelez les fonctions
* Dans le fichier `main.py`, importez tout d'abord le module `operations`
* Créer une fonction `main` et ajouter les instructions dans la fonction :
    * Appelez la fonction `addition` avec les paramètres `3` et `5`
    * Affichez le résultat de l'addition avec la fonction `print`.
    * Appelez la fonction `multiplication` avec les paramètres `8` et `2`
    * Affichez le résultat de la multiplication avec la fonction `print`

#### 3. Appelez la fonction `main`